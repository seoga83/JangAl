#pragma once

#include "PieceParent.h"

class HanPiece : public PieceParent
{
public:
	virtual void Init_Unit();
	virtual void Update_Unit(float a_DeltaTime);
	virtual void Render_Unit(ID2D1HwndRenderTarget* a_pd2dRTarget);
	virtual void Destroy_Unit();
};

