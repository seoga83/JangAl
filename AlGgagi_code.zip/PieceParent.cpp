#include "framework.h"
#include "PieceParent.h"

void PieceParent::Init_Unit()
{
}

void PieceParent::Update_Unit(float a_DeltaTime)
{
}

void PieceParent::Render_Unit(ID2D1HwndRenderTarget* a_pd2dRTarget)
{
}

void PieceParent::Destroy_Unit()
{
}
