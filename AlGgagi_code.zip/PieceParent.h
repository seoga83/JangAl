#pragma once

#pragma comment (lib, "d2d1.lib")     //<---Direct2D ����ϱ�...
#include <d2d1.h>
#include "Vector2D.h"

class PieceParent
{
public:
	bool isActive = true;

	ID2D1Bitmap* m_SocketImg;
	VecINT2D m_ImgSize;
	int m_ImgScale;

	Vector2D m_InitPos;
	Vector2D m_CurPos;
	Vector2D m_DirVec;

	float m_Mass;
	float m_Speed = 0;
	float m_rot = 0;
	float m_ColRad;
	bool isLeftCol;


public:
	virtual void Init_Unit();
	virtual void Update_Unit(float a_DeltaTime);
	virtual void Render_Unit(ID2D1HwndRenderTarget* a_pd2dRTarget);
	virtual void Destroy_Unit();
};

