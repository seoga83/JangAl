#include "framework.h"
#include "HanPiece.h"
#include "GlobalValue.h"

void HanPiece::Init_Unit()
{
}

void HanPiece::Update_Unit(float a_DeltaTime)
{
	m_CurPos = m_CurPos + m_DirVec * m_Speed * a_DeltaTime;

	m_Speed = m_Speed * (1 - 2.9f * a_DeltaTime);

	if (m_Speed <= 7.0f)
		m_Speed = 0.0f;

	if (m_CurPos.x < 327 || m_CurPos.x > 857 ||
		m_CurPos.y < 106 || m_CurPos.y > 658)
	{
		isActive = false;
		g_Number_Han--;
		if (g_Number_Han == 0)
		{
			g_isHanWin = false;
			g_GameState = GameOver;
		}
	}
}

void HanPiece::Render_Unit(ID2D1HwndRenderTarget* a_pd2dRTarget)
{	
	if (g_GameState == PieceMoving && m_Speed != 0)
	{
		if (isLeftCol == true)
			m_rot += 0.06f;
		else
			m_rot -= 0.06f;
	}
	a_pd2dRTarget->SetTransform(D2D1::Matrix3x2F::Rotation(m_rot,
		D2D1::Point2F(m_CurPos.x, m_CurPos.y)));

	a_pd2dRTarget->DrawBitmap(m_SocketImg,
		D2D1::RectF(m_CurPos.x - m_ImgScale, m_CurPos.y - m_ImgScale,
			m_CurPos.x + m_ImgScale, m_CurPos.y + m_ImgScale));	

	a_pd2dRTarget->SetTransform(D2D1::Matrix3x2F::Identity());
}

void HanPiece::Destroy_Unit()
{
	if (m_SocketImg != NULL)
	{
		m_SocketImg->Release();
		m_SocketImg = NULL;
	}
}
